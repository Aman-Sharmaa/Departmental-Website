<head>
    
    <title>Computer Science </title>
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <meta name="mobile-web-app-capable" content="yes">
 <meta charset="UTF-8">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6636701578290691",
    enable_page_level_ads: true
  });
</script>

</head>
<body>

    
    
    
 <div class="navbar">
  <div class="mobile-bar-div">Computer Science Engineering</div>
      <div class="navbar-contain-float"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      
    <div class="navbar-contain">
     <div class="dropdown">

  <span>Videos</span>
  
  <div class="dropdown-content">
  
      <p><a href="firstsemvideo.php">Ist Semester</a></p>
      <p><a href="secondsemvideo.php">2nd Semester</a></p>
      <p><a href="thirdrdsemvideo.php">3rd Semester</a></p>
      <p><a href="fourthsemvideo.php">4th Semester</a></p>
      <p><a href="fifthsemvideo.php">5th Semester</a></p>
      <p><a href="sixthsemvideo.php">6th Semester</a></p>
      <p><a href="sevensemvideo.php">7th Semester</a></p>
      <p><a href="eightsemvideo.php">8th Semester</a></p>
      
  </div> </div></div>
     
  <div class="navbar-contain">
     <div class="dropdown">

  <span>Other</span>
  
  <div class="dropdown-content">
  
      <p><a href="">Department Videos</a></p>
      <p><a href="department-gallery.php">Department Gallery</a></p>
      <p><a href="facultymember.php">Faculty Member</a></p>
      <p><a href="studentdetails.php">Students</a></p>
      <p><a href="alumnireg.php">Alumni Register</a></p>
     
      
  </div> </div></div>
     
      <div class="navbar-contain"><a href="">About </a></div>


      <div class="navbar-contain-right-upload">
     <a href="admin.php" style="color: red;">Admin</a> 
</div>


     </div>
 
  </div>
    









<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>








      <div class="navbar-contain"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      <div class="navbar-contain">
     <a href="admin.php" style="color: red;">Admin</a> 
</div>











 
</div>
<div class="zero">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span></div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>







     <div class="news-link-job-div-div">
        
      
    
       <div class="contain-left"><h1>I M P O R T A N T - L I N K S</h1>      
           
          
 <?php

$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'link');
 
 $q = "select * from linkdata ";

 $query = mysqli_query($con,$q);

           
 while($res = mysqli_fetch_array($query)){
     
 ?>
           
 <tr>
 <td> 
    
     <p> <a href="<?php echo $res['linklink'];  ?>"><?php echo $res['link'];  ?> </a></p>
  

 </tr>

 <?php 
 }
 ?>
 
 </table>  

 </div>
 </div>