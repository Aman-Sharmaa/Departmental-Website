 <?php


$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'job');
 



$id = $_GET['id'];

$q = " DELETE FROM `jobdata` WHERE id = $id ";

mysqli_query($con, $q);

header('location:jobuploaddata.php');

?>