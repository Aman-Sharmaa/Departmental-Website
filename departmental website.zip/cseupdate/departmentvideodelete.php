 <?php


$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'departmentvideo');
 



$id = $_GET['id'];

$q = " DELETE FROM `departmentvideodata` WHERE id = $id ";

mysqli_query($con, $q);

header('location:departmentvideouploaddata.php');

?>