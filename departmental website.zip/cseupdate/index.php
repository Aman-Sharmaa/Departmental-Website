
<head>
    
    <title>Computer Science Engineering</title>
 <link rel="stylesheet" href="style.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <meta name="mobile-web-app-capable" content="yes">
 <meta charset="UTF-8">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6636701578290691",
    enable_page_level_ads: true
  });
</script>

</head>
<body>

    
    
    
 <div class="navbar">
  <div class="mobile-bar-div">Computer Science Engineering</div>
      <div class="navbar-contain-float"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      
    <div class="navbar-contain">
     <div class="dropdown">

  <span>Videos</span>
  
  <div class="dropdown-content">
  
      <p><a href="firstsemvideo.php">Ist Semester</a></p>
      <p><a href="secondsemvideo.php">2nd Semester</a></p>
      <p><a href="thirdrdsemvideo.php">3rd Semester</a></p>
      <p><a href="fourthsemvideo.php">4th Semester</a></p>
      <p><a href="fifthsemvideo.php">5th Semester</a></p>
      <p><a href="sixthsemvideo.php">6th Semester</a></p>
      <p><a href="sevensemvideo.php">7th Semester</a></p>
      <p><a href="eightsemvideo.php">8th Semester</a></p>
      
  </div> </div></div>
     
  <div class="navbar-contain">
     <div class="dropdown">

  <span>Other</span>
  
  <div class="dropdown-content">
  
      <p><a href="departmentvideo.php">Department Videos</a></p>
      <p><a href="department-gallery.php">Department Gallery</a></p>
      <p><a href="facultymember.php">Faculty Member</a></p>
      <p><a href="studentdetails.php">Students</a></p>
      <p><a href="alumnireg.php">Alumni Register</a></p>
     
      
  </div> </div></div>
     
      <div class="navbar-contain"><a href="">About </a></div>


      <div class="navbar-contain-right-upload">
     <a href="admin.php" style="color: green;">Login</a> 
</div>


     </div>
 
  </div>
    









<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>








      <div class="navbar-contain"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      <div class="navbar-contain">
     <a href="admin.php" style="color: red;">Admin</a> 
</div>











 
</div>
<div class="zero">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span></div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>



    
    
 <div class="nav-back-wall">
    
  
    <div class="overlay">
        <h1>Computer Science Engineering</p></h1>
        
         <div class="overlay-right">
             <div class="right-input"><p>T I M E L I N E</p></div>
         </div>
	   
	   
      
      </div>
    </div>


 <div class="news-link-job">



    <div class="news-link-job-div">
        
      
    
       <div class="contain-left"><h1>N E W S</h1>      
           
           

 <?php

 $con = mysqli_connect('localhost','root');

mysqli_select_db($con,'cse');
 
 $q = "select * from newsdata ";

 $query = mysqli_query($con,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr>
 
     
     <p><a href=" <?php echo $res['newslink'];  ?>"> <?php echo $res['news'];  ?></a> </p>


 </tr>

 <?php 
 }
 ?>
 


 </div>
 </div>


 
 
         
 

   
 
    <div class="news-link-job-div">
        
      
    
       <div class="contain-left"><h1>I M P O R T A N T - L I N K S</h1>      
           
          
 <?php

$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'cse');
 
 $q = "select * from linkdata ";

 $query = mysqli_query($con,$q);

           
 while($res = mysqli_fetch_array($query)){
     
 ?>
           
 <tr>
 <td> 
    
     <p> <a href="<?php echo $res['linklink'];  ?>"><?php echo $res['link'];  ?> </a></p>
  

 </tr>

 <?php 
 }
 ?>
 
 </table>  

 </div>
 </div>

    
    <div class="news-link-job-div">
        
      
    
       <div class="contain-left"><h1>J O B S</h1>      
           
    
 <?php

$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'cse');
 
 $q = "select * from jobdata ";

 $query = mysqli_query($con,$q);

 while($res = mysqli_fetch_array($query)){
 ?>


  
           <p><a href="<?php echo $res['joblink'];  ?> "><?php echo $res['job'];  ?></a></p>
 



 <?php 
 }
 ?>
 
 </table>  

 </div>
 </div>
   
</div>




<div class="courses-library">

<div class="courses-library-divs"><div class="overlay2"><h1><a href="ebooks.html"> Books</h1></div>.</div></a>
  <div class="courses-library-divs"><div class="overlay2"><h1> <a href="notes.html"> Notes</h1></div></div></a>
 <div class="courses-library-divs"><div class="overlay2"><h1>  <a href="question.html"> Question Paper</h1></div></div></a>
   <a href=""> <div class="courses-library-divs"><div class="overlay2"><h1>Other Paper</h1></div></div></a>
  <div class="courses-library-divs"><div class="overlay2"><h1><a href="programminglanguage.php">Other Courses</a></h1></div></div></a>



</div>
    
    





<div class="about-cse-dept">
    <div class="cse-about">Welcome to Biotechnology Engineering, Bundelkhand University </div>

    <div class="cse-quote">At Bundelkhand University, we inspire innovation and entrepreneurial thinking aligned to societal needs and scientific advancements. Our Biotechnology program trains students to develop technological solutions to problems in health, nutrition,
            environment, and energy. Our curriculum offers multidisciplinary specialization in biomedical devices, biosensors, clinical informatics, biological data mining, and other emerging areas. Our pedagogy encourages imbibing practical skills that
            can be honed through project-based learning and by studying real-world case scenarios. We nurture tomorrow's engineers and technologists who can design, test, and manufacture biological systems and bio-based products for diverse applications.
        



</div>

    


<div class="contact-slide">
     <h1>Contact</h1>
    
    
    <div class="contact-left">
        <p><i class="fa fa-map-marker" aria-hidden="true"></i>
         Biotechnology Department</p>
        <p><i class="fa fa-envelope" aria-hidden="true"></i>
 example@gmail.com</p>
        <p><i class="fa fa-phone" aria-hidden="true"></i>
 +91 XXXXXXXXXXX</p>
    
    </div>
    
    <div class="contact-right">
        


     <form acton="index.php">
         <input type="email" name="email" class="text" placeholder="Email" required>
     <input type="text" name="name" class="text" placeholder="Name" required>
     
     <input type="message" name="message" class="message" placeholder="Message" required>
        <button>Send</button>
            
        </form>
        
    
    </div>

</div>

  
     

<div class="main-content-c">
    
          <h1>About Us</h1>
		  <p>All Rights Reserved</p>
          <p>copyright 2019-2021</p>
          <p>Contact No: 9506521413 </p>
          <p>Email:amansharma57269@gmail.com</p>
          <p>www.ietcse.in</p>
          <p>Design & developed by:- Aman Sharma</p>
   
		 
         
   </div>
         
  

         
<script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>
           
  

</body>
