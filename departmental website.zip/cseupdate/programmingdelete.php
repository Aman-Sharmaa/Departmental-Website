 <?php


$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'programming');
 



$id = $_GET['id'];

$q = " DELETE FROM `programmingdata` WHERE id = $id ";

mysqli_query($con, $q);

header('location:programmingupload.php');

?>