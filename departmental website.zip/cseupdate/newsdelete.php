 <?php


$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'news');
 



$id = $_GET['id'];

$q = " DELETE FROM `newsdata` WHERE id = $id ";

mysqli_query($con, $q);

header('location:newsuploaddata.php');

?>