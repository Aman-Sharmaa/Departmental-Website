<!DOCTYPE html>
<html>
<head>
 <title></title>
<link rel=" stylesheet" href="uploadstyle.css">
<link rel=" stylesheet" href="style.css">
</head>
<body>

    
    
    
 <div class="navbar">
  <div class="mobile-bar-div">Computer Science Engineering</div>
      <div class="navbar-contain-float"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      
    <div class="navbar-contain">
     <div class="dropdown">

  <span>Videos</span>
  
  <div class="dropdown-content">
  
      <p><a href="firstsemvideo.php">Ist Semester</a></p>
      <p><a href="secondsemvideo.php">2nd Semester</a></p>
      <p><a href="thirdrdsemvideo.php">3rd Semester</a></p>
      <p><a href="fourthsemvideo.php">4th Semester</a></p>
      <p><a href="fifthsemvideo.php">5th Semester</a></p>
      <p><a href="sixthsemvideo.php">6th Semester</a></p>
      <p><a href="sevensemvideo.php">7th Semester</a></p>
      <p><a href="eightsemvideo.php">8th Semester</a></p>
      
  </div> </div></div>
     
  <div class="navbar-contain">
     <div class="dropdown">

  <span>Other</span>
  
  <div class="dropdown-content">
  
      <p><a href="">Department Videos</a></p>
      <p><a href="department-gallery.php">Department Gallery</a></p>
      <p><a href="facultymember.php">Faculty Member</a></p>
      <p><a href="studentdetails.php">Students</a></p>
      <p><a href="alumnireg.php">Alumni Register</a></p>
     
      
  </div> </div></div>
     
      <div class="navbar-contain"><a href="">About </a></div>


      <div class="navbar-contain-right-upload">
     <a href="admin.php" style="color: red;">Admin</a> 
</div>


     </div>
 
  </div>
    









<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>








      <div class="navbar-contain"><a href="index.php">Home</a></div>
      <div class="navbar-contain"><a href="news.php">News</a></div>
      <div class="navbar-contain"><a href="importantlink.php">Important link</a></div>
      <div class="navbar-contain"><a href="job.php">Job</a></div>
      <div class="navbar-contain"><a href="gallery.php">Gallery</a></div>
      <div class="navbar-contain">
     <a href="admin.php" style="color: red;">Admin</a> 
</div>











 
</div>
<div class="zero">
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span></div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>






 <table >
 
     <div class="admin-page">
         <a href="admin.php">back</a></div>
     
 <div class="admin-upload-manage-data">
 
 <h1 > Manage Data Table Data </h1>

 <p> Job </p>
 <p> Delete </p>
 <p> Update </p>

 </div>

 <?php

 


$con = mysqli_connect('localhost','root');

mysqli_select_db($con,'job');
 


 $q = "select * from jobdata ";

 $query = mysqli_query($con,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr>
 <div class="admin-upload-manage-data">
     <h2><a href=" <?php echo $res['joblink'];  ?>"> <?php echo $res['job'];  ?></a> </h2>
     <h2> <button > <a href="jobdelete.php?id=<?php echo $res['id']; ?>" > Delete </a>  </button> </h2>
     <h2> <button > <a href="jobupdate.php?id=<?php echo $res['id']; ?>" > Update </a> </button> </h2>
     </div>
 </tr>

 <?php 
 }
 ?>
 
 </table>  

 </div>
 </div>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>

</body>
</html>